from player import Player, PlayerAction
from card import Card
class PokerBot(Player):
    def __init__(self, name, stack):
        super().__init__(name, stack)
        self.opponent_actions = {'raise': 0, 'call': 0, 'fold': 0, 'check': 0}
        self.opponent_stacks = {}
        self.total_opponent_actions = 0

    def update_opponent_behavior(self, action, opponent_stack):
        """Update opponent behavior and track their remaining stack."""
        if action[2] in self.opponent_actions:
            self.opponent_actions[action[2]] += 1
            self.total_opponent_actions += 1
        self.opponent_stacks[action[1]] = opponent_stack

    def get_opponent_tendency(self):
        """Determine opponent's tendencies based on action history and remaining stack."""
        if self.total_opponent_actions == 0:
            return "neutral"

        raise_percentage = self.opponent_actions['raise'] / self.total_opponent_actions
        fold_percentage = self.opponent_actions['fold'] / self.total_opponent_actions
        call_percentage = self.opponent_actions['call'] / self.total_opponent_actions
        avg_stack = sum(self.opponent_stacks.values()) / len(self.opponent_stacks) if self.opponent_stacks else 1

        if raise_percentage > 0.4 and avg_stack > self.stack * 1.5:
            return "very aggressive"
        elif raise_percentage > 0.4:
            return "aggressive"
        elif fold_percentage > 0.5 and avg_stack < self.stack * 0.5:
            return "tight-passive"
        elif fold_percentage > 0.5:
            return "tight"
        elif call_percentage > 0.5 and avg_stack > self.stack * 1.5:
            return "loose-aggressive"
        elif call_percentage > 0.5:
            return "loose"
        else:
            return "neutral"

    def evaluate_preflop(self, hole_cards):
        """Evaluate pre-flop hand strength using poker hand rankings."""
        ranks = sorted([(i%13)+1 for i in hole_cards], reverse=True)
        suits = [i//13 for i in hole_cards]

        is_pair = ranks[0] == ranks[1]
        is_suited = suits[0] == suits[1]
        is_connected = abs(ranks[0] - ranks[1]) == 1

        if is_pair:
            return 1.0 if ranks[0] >= 10 else 0.8 if ranks[0] >= 7 else 0.6  # Strong, Medium, Weak Pairs
        if is_suited and is_connected:
            return 0.8 if ranks[0] >= 10 else 0.7  # High vs. Medium Suited Connectors
        if is_suited or is_connected:
            return 0.6 if ranks[0] >= 10 else 0.5  # High Suited or Connected Cards
        if ranks[0] >= 12:
            return 0.4  # High-card hands (AQ, KJ, etc.)
        return 0.2  # Weak hands

    def evaluate_flop(self, hole_cards, community_cards):
        return self.evaluate_postflop(hole_cards, community_cards[:3])

    def evaluate_turn(self, hole_cards, community_cards):
        return self.evaluate_postflop(hole_cards, community_cards[:4])

    def evaluate_river(self, hole_cards, community_cards):
        return self.evaluate_postflop(hole_cards, community_cards)

    def evaluate_postflop(self, hole_cards, community_cards):
        """Evaluate hand strength for post-flop stages using all poker hand rankings."""
        all_cards = sorted(hole_cards+community_cards)

        ranks = [(i%13)+1 for i in all_cards]
        suits = [i//13 for i in all_cards]

        def is_flush():
            return max(suits.count(suit) for suit in set(suits)) >= 5

        def is_straight():
            unique_ranks = sorted(set(ranks))
            for i in range(len(unique_ranks) - 4):
                if unique_ranks[i + 4] - unique_ranks[i] == 4:
                    return True
            return False

        rank_counts = {rank: ranks.count(rank) for rank in set(ranks)}
        pairs = [rank for rank, count in rank_counts.items() if count == 2]
        three_of_a_kinds = [rank for rank, count in rank_counts.items() if count == 3]
        four_of_a_kinds = [rank for rank, count in rank_counts.items() if count == 4]

        if is_flush() and is_straight():
            return 1.0  # Straight flush
        elif four_of_a_kinds:
            return 0.9  # Four of a kind
        elif three_of_a_kinds and pairs:
            return 0.85  # Full house
        elif is_flush():
            return 0.8  # Flush
        elif is_straight():
            return 0.75  # Straight
        elif three_of_a_kinds:
            return 0.7  # Three of a kind
        elif len(pairs) >= 2:
            return 0.6  # Two pair
        elif pairs:
            return 0.5  # One pair
        else:
            return 0.2  # High card

    def decide_action(self, game_state, action_history):
        hole_cards = game_state[:2]
        community_cards = [card for card in game_state[2:7] if card != 0]
        PRE_FLOP, FLOP, TURN, RIVER = 0, 1, 2, 3 
        phase = game_state[-2]
        current_raise = game_state[8]
        strength=0
        for action in action_history:
            if action[1] != self.name:
             print(f"Updating behavior: {action[1]} {action[2]} {action[3]}")
             self.update_opponent_behavior(action, action[3])

        opponent_tendency = self.get_opponent_tendency()
        print("Opponent Tendency:", opponent_tendency)

        if phase == PRE_FLOP:
            strength = self.evaluate_preflop(hole_cards)
        elif phase == FLOP:
            strength = self.evaluate_flop(hole_cards, community_cards)
        elif phase == TURN:
            strength = self.evaluate_turn(hole_cards, community_cards)
        elif phase == RIVER:
            strength = self.evaluate_river(hole_cards, community_cards)

        print(f"Hand strength: {strength}")

        if phase == RIVER and strength > 0.9:
            return PlayerAction.ALL_IN, self.stack
        elif phase == FLOP and strength > 0.7:
            return PlayerAction.ALL_IN, self.stack
        elif strength > 0.8:
            return PlayerAction.RAISE, min(self.stack, current_raise * 2)
        elif strength > 0.5:
            if opponent_tendency == 'aggressive':
                return PlayerAction.CALL, current_raise
            else:
                return PlayerAction.RAISE, min(self.stack, current_raise)
        return (PlayerAction.CALL, current_raise) if opponent_tendency == 'loose' else (PlayerAction.FOLD, 0)


    def action(self, game_state, action_history):
        return self.decide_action(game_state, action_history)
