import numpy as np
import random
from player import Player, PlayerAction, PlayerStatus
from card import Card, Deck
from hand_evaluator import HandEvaluator

class EnhancedBot(Player):
    def __init__(self, name="Enhanced AI PokerBot", stack=1000):
        super().__init__(name, stack)
        # Define actions available.
        self.actions = [PlayerAction.FOLD, PlayerAction.CHECK, PlayerAction.CALL, 
                        PlayerAction.BET, PlayerAction.RAISE, PlayerAction.ALL_IN]
        self.num_actions = len(self.actions)
        
        # Increase feature dimension to incorporate estimated hand equity.
        self.feature_dim = 12  
        # Initialize logistic regression weights and biases (to be trained in a full system).
        self.W = np.random.randn(self.num_actions, self.feature_dim)
        self.b = np.random.randn(self.num_actions)
        
        # Cumulative regrets for CFR-style strategy updates.
        self.regret_sum = np.zeros(self.num_actions)
        self.strategy_sum = np.zeros(self.num_actions)
    
    def get_features(self, game_state):
        """
        Extracts a feature vector from the game_state. The game_state structure:
         - indices 0-1: your 2 hole card indices,
         - indices 2-6: 5 community card indices (0 if not dealt),
         - index 7: pot,
         - index 8: current bet,
         - index 9: big blind,
         - index 10: active player index,
         - index 11: number of players,
         - indices 12 onward: each player's stack,
         - last element: game number.
        
        Features include normalized pot, current bet, big blind, stack, number of players,
        hole cards, count of community cards, and estimated hand equity.
        """
        features = np.zeros(self.feature_dim)
        pot = game_state[7]
        current_bet = game_state[8]
        big_blind = game_state[9]
        active_index = game_state[10]
        num_players = game_state[11]
        my_stack = game_state[12 + active_index]
        
        features[0] = pot / 1000.0
        features[1] = current_bet / 100.0
        features[2] = big_blind / 100.0
        features[3] = my_stack / 1000.0
        features[4] = num_players / 10.0
        
        # Normalize hole cards (indices between 0 and 51).
        card1 = game_state[0]
        card2 = game_state[1]
        features[5] = card1 / 52.0
        features[6] = card2 / 52.0
        
        # Count community cards dealt.
        community_count = sum(1 for x in game_state[2:7] if x != 0)
        features[7] = community_count / 5.0
        
        # Placeholder for extra board features.
        features[8] = community_count / 5.0
        
        # Estimated hand equity as a feature.
        features[9] = self.estimate_hand_equity(game_state, simulations=100)
        
        # Exploration/random factors.
        features[10] = random.random()
        features[11] = random.random()
        return features

    def softmax(self, x):
        e_x = np.exp(x - np.max(x))
        return e_x / e_x.sum()
    
    def get_regret_adjusted_strategy(self):
        """
        Computes a strategy distribution based on cumulative regrets using regret matching.
        """
        positive_regrets = np.maximum(self.regret_sum, 0)
        total = positive_regrets.sum()
        if total > 0:
            strategy = positive_regrets / total
        else:
            strategy = np.ones(self.num_actions) / self.num_actions
        return strategy
    
    def estimate_hand_equity(self, game_state, simulations=100):
        """
        Estimates hand equity by simulating random completions of the board and random opponent hands.
        Returns an equity value between 0 and 1.
        """
        # Extract known cards.
        hole_indices = game_state[0:2]
        community_indices = [c for c in game_state[2:7] if c != 0]
        community_count = len(community_indices)
        
        # Build the available deck (0-51) excluding known cards.
        full_deck = list(range(52))
        used = set(hole_indices + community_indices)
        available = [c for c in full_deck if c not in used]
        
        wins = 0
        ties = 0
        total = 0
        
        # Number of opponents (assume all players except self).
        num_players = game_state[11]
        num_opponents = max(num_players - 1, 1)
        
        for _ in range(simulations):
            deck_copy = available.copy()
            random.shuffle(deck_copy)
            
            # Complete the board.
            needed = 5 - community_count
            sim_community = community_indices + deck_copy[:needed]
            deck_remaining = deck_copy[needed:]
            
            # Convert indices to Card objects.
            my_cards = [self.index_to_card(idx) for idx in hole_indices]
            community_cards = [self.index_to_card(idx) for idx in sim_community]
            my_result = HandEvaluator.evaluate_hand(my_cards, community_cards)
            
            opponent_better = False
            opponent_equal = 0
            for _ in range(num_opponents):
                opp_indices = [deck_remaining.pop(), deck_remaining.pop()]
                opp_cards = [self.index_to_card(idx) for idx in opp_indices]
                opp_result = HandEvaluator.evaluate_hand(opp_cards, community_cards)
                # Compare hands.
                if (opp_result.hand_rank.value > my_result.hand_rank.value or
                    (opp_result.hand_rank.value == my_result.hand_rank.value and 
                     opp_result.hand_value > my_result.hand_value)):
                    opponent_better = True
                elif (opp_result.hand_rank.value == my_result.hand_rank.value and 
                      opp_result.hand_value == my_result.hand_value):
                    opponent_equal += 1
            if not opponent_better:
                # Win if no opponent has a better hand.
                wins += 1
                if opponent_equal > 0:
                    ties += opponent_equal
            total += 1
        
        equity = (wins + 0.5 * ties) / total if total > 0 else 0
        return equity
    
    def index_to_card(self, idx):
        """
        Converts a card index (0-51) to a Card object.
        """
        from card import Card, Suit, Rank
        suit_value = idx // 13
        rank_value = (idx % 13) + 2  # Rank.TWO = 2
        rank = next((r for r in Rank if r.value == rank_value), None)
        suit = next((s for s in Suit if s.value == suit_value), None)
        return Card(rank, suit)
    
    def simulate_monte_carlo(self, game_state, action_index, simulations=20):
        """
        Uses Monte Carlo simulation to produce an expected value for an action.
        Here we combine estimated hand equity with an action-specific bias.
        """
        equity = self.estimate_hand_equity(game_state, simulations=simulations)
        # More aggressive actions (higher action_index) gain extra value if equity is high.
        action_bias = action_index * 0.05
        return equity + action_bias

    def update_regrets(self, chosen_index, simulation_values):
        """
        Updates the regret sums based on simulation values.
        For demonstration, assume simulation_values is an array with an estimated value for each action.
        The regret for each action is the difference between its simulation value and the value of the chosen action.
        """
        chosen_value = simulation_values[chosen_index]
        for i in range(self.num_actions):
            regret = simulation_values[i] - chosen_value
            self.regret_sum[i] += regret
            self.strategy_sum[i] += self.get_regret_adjusted_strategy()[i]
    
    def action(self, game_state, action_history):
        """
        Computes a move by combining:
         1. Feature extraction with logistic regression for probabilities.
         2. A CFR-based strategy from historical regrets.
         3. Monte Carlo simulation to estimate outcomes.
         4. Dynamic bet sizing based on estimated hand equity.
        
        Returns a tuple (chosen_action, amount).
        """
        # Extract features and compute logistic regression probabilities.
        features = self.get_features(game_state)
        logits = self.W.dot(features) + self.b
        lr_probs = self.softmax(logits)
        
        # Get CFR (regret-matched) strategy.
        cfr_strategy = self.get_regret_adjusted_strategy()
        combined_strategy = 0.5 * lr_probs + 0.5 * cfr_strategy
        
        # Monte Carlo simulation for each action.
        mc_values = np.array([self.simulate_monte_carlo(game_state, i) for i in range(self.num_actions)])
        
        # Compute scores for actions.
        scores = combined_strategy * mc_values
        best_action_index = int(np.argmax(scores))
        chosen_action = self.actions[best_action_index]
        
        # Optionally update regrets (in a full system, this update would occur after observing hand outcome).
        self.update_regrets(best_action_index, mc_values)
        
        # Determine betting amount dynamically.
        if chosen_action in [PlayerAction.BET, PlayerAction.RAISE]:
            equity = self.estimate_hand_equity(game_state, simulations=50)
            amount = int(self.stack * (0.1 + 0.5 * equity))
            amount = max(amount, 10)
        elif chosen_action == PlayerAction.CALL:
            amount = game_state[8]  # current bet from game state.
        else:
            amount = 0
        
        return chosen_action, amount
